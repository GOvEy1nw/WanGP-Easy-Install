@Echo off
setlocal EnableDelayedExpansion
cd /D "%~dp0"

set "WEI_ROOT=%~dp0..\..\.."
for %%I in ("%WEI_ROOT%") do set "WEI_ROOT=%%~fI"

if not exist "%WEI_ROOT%\python_embedded\python.exe" (
    echo Run WanGP-Easy-Install.bat first.
    if /I not "%~1"=="NoPause" pause
    exit /b 1
)

set "HLPR_ZIP=%WEI_ROOT%\..\Helper-WEI.zip"
if not exist "%HLPR_ZIP%" (
    echo Helper-WEI.zip not found next to WanGP-Easy-Install.bat.
    if /I not "%~1"=="NoPause" pause
    exit /b 1
)

echo Updating WanGP-Easy-Install from Helper-WEI.zip...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$b=[IO.File]::ReadAllBytes('%HLPR_ZIP%'); if($b.Length -lt 4 -or $b[0] -ne 80 -or $b[1] -ne 75){Write-Error 'Invalid zip'; exit 1}"
if errorlevel 1 (
    echo ERROR: Helper-WEI.zip is not a valid zip file.
    if /I not "%~1"=="NoPause" pause
    exit /b 1
)

tar.exe -xf "%HLPR_ZIP%" -C "%WEI_ROOT%\.."
if errorlevel 1 (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%HLPR_ZIP%' -DestinationPath '%WEI_ROOT%\..' -Force"
)

echo Done.
if /I not "%~1"=="NoPause" pause
exit /b 0
