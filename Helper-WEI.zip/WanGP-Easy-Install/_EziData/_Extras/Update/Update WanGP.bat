@Echo off
setlocal EnableDelayedExpansion
cd /D "%~dp0"

set "WEI_ROOT=%~dp0..\..\.."
for %%I in ("%WEI_ROOT%") do set "WEI_ROOT=%%~fI"

set "path=%windir%\System32;%windir%\System32\WindowsPowerShell\v1.0;%PATH%"
for /f "delims=" %%G in ('cmd /c "where.exe git.exe 2>nul"') do (set "GIT_PATH=%%~dpG")
set "path=%GIT_PATH%;%path%"

if not exist "%WEI_ROOT%\python_embedded\python.exe" (
    echo Run WanGP-Easy-Install.bat first.
    if /I not "%~1"=="NoPause" pause
    exit /b 1
)

echo Updating WanGP source...
git -C "%WEI_ROOT%\WanGP" pull

echo.
echo Updating Python dependencies...
"%WEI_ROOT%\python_embedded\python.exe" -I -m uv pip install -r "%WEI_ROOT%\WanGP\requirements.txt" --no-cache

echo.
echo Done.
if /I not "%~1"=="NoPause" pause
exit /b 0
