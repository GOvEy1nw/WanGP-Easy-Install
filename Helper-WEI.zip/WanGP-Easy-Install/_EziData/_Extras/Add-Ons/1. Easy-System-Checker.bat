@echo off
setlocal EnableDelayedExpansion
cd /D "%~dp0"
Title Easy System Checker for WanGP Easy Install

set "WEI_ROOT=%~dp0"
:find_wei_root
if exist "%WEI_ROOT%python_embedded\python.exe" goto :wei_root_found
set "WEI_ROOT=%WEI_ROOT%..\"
goto :find_wei_root
:wei_root_found
for %%I in ("%WEI_ROOT%.") do set "WEI_ROOT=%%~fI"
set "PYTHON_EXE=%WEI_ROOT%\python_embedded\python.exe"
set "CONFIG_LIB=%WEI_ROOT%\_EziData\Config\lib"

if not exist "!PYTHON_EXE!" (
    echo.
    echo    python_embedded not found. Run WanGP-Easy-Install.bat first.
    echo.
    pause
    exit /b 1
)

echo.
echo    Easy-System-Checker for WanGP
echo    Install root: !WEI_ROOT!
echo.

"!PYTHON_EXE!" -I "!CONFIG_LIB!\install_helper.py" --detect
echo.

for /f "tokens=2" %%i in ('"!PYTHON_EXE!" --version 2^>^&1') do echo    Python: %%i
for /f "tokens=1,2 delims=|" %%a in ('"!PYTHON_EXE!" -c "import torch; v=torch.__version__.split(chr(43))[0]; cv=torch.version.cuda or chr(78); print(v+chr(124)+cv)" 2^>nul') do (
    echo    PyTorch: %%a
    echo    CUDA: %%b
)

if exist "!WEI_ROOT!\_EziData\Config\install_profile.json" (
    echo.
    echo    install_profile.json:
    type "!WEI_ROOT!\_EziData\Config\install_profile.json"
)

if exist "!WEI_ROOT!\WanGP\.git" (
    echo.
    for /f %%h in ('git -C "!WEI_ROOT!\WanGP" rev-parse --short HEAD 2^>nul') do echo    WanGP commit: %%h
)

echo.
echo    Installed kernels:
"!PYTHON_EXE!" -m pip list 2>nul | findstr /I "triton sage flash nunchaku sparge bitsandbytes llama lightx2v"

echo.
pause
exit /b 0
