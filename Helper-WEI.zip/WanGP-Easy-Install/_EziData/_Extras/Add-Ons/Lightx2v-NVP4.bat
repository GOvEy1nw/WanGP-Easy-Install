@echo off
setlocal EnableDelayedExpansion
cd /D "%~dp0"
Title Lightx2v NVP4 for WanGP Easy Install

set "WEI_ROOT=%~dp0"
:find_wei_root
if exist "%WEI_ROOT%python_embedded\python.exe" goto :wei_root_found
set "WEI_ROOT=%WEI_ROOT%..\"
goto :find_wei_root
:wei_root_found
for %%I in ("%WEI_ROOT%.") do set "WEI_ROOT=%%~fI"
set "PYTHON_EXE=%WEI_ROOT%\python_embedded\python.exe"
set "CONFIG_LIB=%WEI_ROOT%\_EziData\Config\lib"

set green=[92m
set yellow=[93m
set reset=[0m

if not exist "!PYTHON_EXE!" (
    echo.
    echo    python_embedded not found. Run WanGP-Easy-Install.bat first.
    echo.
    if "%~1"=="" pause
    exit /b 1
)

for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort 7860 -State Listen -ErrorAction SilentlyContinue) { 1 } else { 0 }"') do set "INUSE=%%A"
if "!INUSE!"=="1" (
    echo.
    echo    WanGP is already running on port 7860. Close it before running this add-on.
    echo.
    if "%~1"=="" pause
    exit /b 1
)

echo.
echo !green!:::::::::::::: Installing !yellow!Lightx2v NVFP4 kernels!reset!
echo.
"!PYTHON_EXE!" -I "!CONFIG_LIB!\install_helper.py" --install-kernel lightx2v
echo.
echo !green!:::::::::::::: Lightx2v NVP4 installation complete!reset!
if "%~1"=="" pause
exit /b 0
