@echo off
setlocal EnableDelayedExpansion
cd /D "%~dp0"
Title Torch 2.9.0+cu128 for WanGP Easy Install (legacy driver)

set "WEI_ROOT=%~dp0"
:find_wei_root
if exist "%WEI_ROOT%python_embedded\python.exe" goto :wei_root_found
set "WEI_ROOT=%WEI_ROOT%..\"
goto :find_wei_root
:wei_root_found
for %%I in ("%WEI_ROOT%.") do set "WEI_ROOT=%%~fI"
set "PYTHON_EXE=%WEI_ROOT%\python_embedded\python.exe"
set "CONFIG_LIB=%WEI_ROOT%\_EziData\Config\lib"

set green=[92m
set yellow=[93m
set reset=[0m

if not exist "!PYTHON_EXE!" (
    echo.
    echo    python_embedded not found. Run WanGP-Easy-Install.bat first.
    echo.
    pause
    exit /b 1
)

for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort 7860 -State Listen -ErrorAction SilentlyContinue) { 1 } else { 0 }"') do set "INUSE=%%A"
if "!INUSE!"=="1" (
    echo.
    echo    WanGP is already running on port 7860. Close it first.
    echo.
    pause
    exit /b 1
)

echo.
echo !yellow!Warning: Legacy cu128 stack. Some wheels are cp310-only. Driver 580+ recommended.!reset!
echo.
echo !green!::::::::::::::: Installing Torch 2.9.0 + cu128!reset!
echo.
"!PYTHON_EXE!" -I "!CONFIG_LIB!\install_helper.py" --install-torch --cuda-stack cu128
echo.

"!PYTHON_EXE!" -m pip show sageattention >nul 2>&1
if not errorlevel 1 call "%~dp0..\Add-Ons\SageAttention.bat" NoPause

"!PYTHON_EXE!" -m pip show flash-attn >nul 2>&1
if not errorlevel 1 call "%~dp0..\Add-Ons\FlashAttention.bat" NoPause

"!PYTHON_EXE!" -m pip show nunchaku >nul 2>&1
if not errorlevel 1 call "%~dp0..\Add-Ons\Nunchaku.bat" NoPause

"!PYTHON_EXE!" -m pip show spas-sage-attn >nul 2>&1
if not errorlevel 1 call "%~dp0..\Add-Ons\SpargeAttention.bat" NoPause

"!PYTHON_EXE!" -m pip show llamacpp_gguf_cuda >nul 2>&1
if not errorlevel 1 call "%~dp0..\Add-Ons\GGUF-Kernels.bat" NoPause

echo.
echo !green!:::::::: Torch 2.9.0+cu128 installation complete!reset!
pause
exit /b 0
