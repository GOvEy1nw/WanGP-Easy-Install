@Echo off&&cd /D %~dp0
Title Windows Long Paths Enabler for WanGP Easy Install

setlocal EnableExtensions EnableDelayedExpansion
call :set_colors

reg query "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v LongPathsEnabled >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v LongPathsEnabled ^| find "LongPathsEnabled"') do (
        if /I "%%A"=="0x1" (
            echo.
            echo %green%Long Paths are already enabled.%reset%
            pause
            exit /b
        )
    )
)

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo %yellow%Requesting administrator rights...%reset%
    powershell -NoProfile -ExecutionPolicy Bypass -command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

reg add "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v LongPathsEnabled /t REG_DWORD /d 1 /f >nul
if %errorlevel%==0 (
    echo %green%Long Paths enabled successfully.%reset%
    echo %yellow%A restart may be required.%reset%
) else (
    echo %red%Failed to modify registry.%reset%
)
pause
exit /b

:set_colors
set     red=[91m
set   green=[92m
set  yellow=[93m
set   reset=[0m
goto :eof
