"""
WanGP-EZi - Desktop shell for WanGP (pywebview + local proxy).
Console/UI toggle, manual updates from settings menu, detached console.
"""

from __future__ import annotations

APP_VERSION = "1.1.0"
EZI_UA_TAG = "WanGP-EZi-Desktop"

import asyncio
import atexit
import ctypes
import json
import os
import shlex
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

try:
    from aiohttp import ClientSession, ClientTimeout, WSMsgType, web
except ImportError:
    print("aiohttp is required. Run: python_embedded\\python.exe -m pip install aiohttp")
    sys.exit(1)

try:
    import webview
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pywebview"])
    import webview

CURRENT_SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
ROOT_DIR = os.path.normpath(os.path.join(CURRENT_SCRIPT_DIR, "..", "..", "..", ".."))
CONFIG_DIR = os.path.join(ROOT_DIR, "_EziData", "Config")
PY_EXE = os.path.join(ROOT_DIR, "python_embedded", "python.exe")
PYW_EXE = os.path.join(ROOT_DIR, "python_embedded", "pythonw.exe")
EZI_SCRIPT = os.path.join(CURRENT_SCRIPT_DIR, "WanGP-EZi.py")
WGP_DIR = os.path.join(ROOT_DIR, "WanGP")
WGP_SCRIPT = os.path.join(WGP_DIR, "wgp.py")
ARGS_FILE = os.path.join(CONFIG_DIR, "args.txt")
SETTINGS_PATH = os.path.join(CURRENT_SCRIPT_DIR, "WanGP-EZi.settings.json")
SHELL_HTML_PATH = os.path.join(CURRENT_SCRIPT_DIR, "WanGP-EZi.shell.html")
WGP_CONFIG_PATH = os.path.join(WGP_DIR, "wgp_config.json")
UPDATE_WANGP_BAT = os.path.join(ROOT_DIR, "_EziData", "_Extras", "Update", "Update WanGP.bat")
UPDATE_WEI_BAT = os.path.join(ROOT_DIR, "_EziData", "_Extras", "Update", "Update Easy-Install.bat")

WANGP_PORT = 7860
WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 900
_NO_WIN = 0x08000000
_NO_WIN_HIDDEN = 0x08000000 | 0x20000000
_SUBPROCESS_FLAGS = 0x08000000 | 0x00000200
_READ_CHUNK_SIZE = 4096


def _check_webview2() -> bool:
    try:
        import winreg

        keys = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
            (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
        ]
        for hive, path in keys:
            try:
                winreg.OpenKey(hive, path)
                return True
            except OSError:
                pass
    except Exception:
        pass
    return False


if not _check_webview2():
    ctypes.windll.user32.MessageBoxW(
        0,
        "WebView2 Runtime was not found.\n\nWanGP-EZi requires Microsoft Edge WebView2.",
        "WanGP-EZi",
        0x10,
    )
    os.startfile("https://developer.microsoft.com/en-us/microsoft-edge/webview2/")
    sys.exit(1)


def _load_settings() -> dict:
    defaults = {
        "hide_deprecation_warnings": True,
        "console_detached": False,
        "window_placement": None,
    }
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH, encoding="utf-8") as file_handle:
                defaults.update(json.load(file_handle))
        except Exception:
            pass
    return defaults


def _save_settings(settings: dict) -> None:
    try:
        allowed = ("hide_deprecation_warnings", "console_detached", "window_placement")
        payload = {key: settings[key] for key in allowed if key in settings}
        with open(SETTINGS_PATH, "w", encoding="utf-8") as file_handle:
            json.dump(payload, file_handle, indent=2)
    except Exception:
        pass


def _load_shell_html() -> str:
    if not hasattr(_load_shell_html, "_cache"):
        if os.path.isfile(SHELL_HTML_PATH):
            with open(SHELL_HTML_PATH, encoding="utf-8") as file_handle:
                _load_shell_html._cache = file_handle.read()
        else:
            _load_shell_html._cache = "<html><body><h1>WanGP-EZi shell missing</h1></body></html>"
    return _load_shell_html._cache


def _sanitize_extra_args_for_ezi(args: list[str]) -> list[str]:
    sanitized: list[str] = []
    index = 0
    while index < len(args):
        arg = args[index]
        if arg == "--open-browser":
            if index + 1 < len(args) and args[index + 1].lower() in ("false", "true"):
                index += 2
            else:
                index += 1
            continue
        if arg.startswith("--open-browser="):
            index += 1
            continue
        sanitized.append(arg)
        index += 1
    return sanitized


def _read_extra_args() -> list[str]:
    if not os.path.exists(ARGS_FILE):
        return []
    try:
        with open(ARGS_FILE, encoding="utf-8") as file_handle:
            content = file_handle.read().strip()
        if not content:
            return []
        return _sanitize_extra_args_for_ezi(shlex.split(content, posix=False))
    except Exception:
        return []


def _wangp_script_args() -> list[str]:
    return ["--server-name", "127.0.0.1", "--server-port", str(WANGP_PORT), *_read_extra_args()]


def _make_wangp_bootstrap(script_args: list[str]) -> str:
    """Match ComfyUI-EZi: merge stderr/logging into stdout for pipe streaming."""
    argv_repr = repr([WGP_SCRIPT, *script_args])
    return (
        "import sys, runpy, logging\n"
        "sys.stderr = sys.stdout\n"
        "_oe = logging.StreamHandler.emit\n"
        "def _patch_emit(self, record):\n"
        "    self.stream = sys.stdout\n"
        "    return _oe(self, record)\n"
        "logging.StreamHandler.emit = _patch_emit\n"
        f"sys.argv = {argv_repr}\n"
        f"runpy.run_path({WGP_SCRIPT!r}, run_name='__main__')\n"
    )


def _wangp_run_env() -> dict[str, str]:
    return os.environ.copy() | {
        "PYTHONUTF8": "1",
        "PYTHONUNBUFFERED": "1",
        "PYTHONIOENCODING": "utf-8",
        "TQDM_NCOLS": "120",
        "TQDM_MININTERVAL": "0.1",
    }


def _decode_pipe_bytes(data: bytes) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def _stream_pipe_output(pipe, run_id: int, active_run_id: int, write_line) -> None:
    """Read subprocess stdout in chunks; handle tqdm-style \\r progress lines."""
    buffer = bytearray()
    prev_cr_line = ""
    while True:
        chunk = pipe.read(_READ_CHUNK_SIZE)
        if not chunk or active_run_id != run_id:
            break
        for byte in chunk:
            if byte == ord(b"\r"):
                line = _decode_pipe_bytes(buffer)
                buffer.clear()
                if line:
                    prev_cr_line = line
                    write_line(line + "\r")
            elif byte == ord(b"\n"):
                line = _decode_pipe_bytes(buffer)
                buffer.clear()
                if not line and prev_cr_line:
                    write_line("\n")
                    line = prev_cr_line
                else:
                    write_line(line + "\n")
                prev_cr_line = ""
            else:
                prev_cr_line = ""
                buffer.append(byte)
    if buffer and active_run_id == run_id:
        write_line(_decode_pipe_bytes(buffer))


def _find_free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("", 0))
        return sock.getsockname()[1]


def _wait_for_tcp_port(port: int, timeout: float = 2.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.05):
                return True
        except OSError:
            time.sleep(0.01)
    return False


def _http_ready(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2) as response:
            return 200 <= response.status < 500
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def _resolve_output_dir() -> str:
    save_path = "outputs"
    if os.path.isfile(WGP_CONFIG_PATH):
        try:
            with open(WGP_CONFIG_PATH, encoding="utf-8") as file_handle:
                config = json.load(file_handle)
            save_path = config.get("save_path") or config.get("image_save_path") or "outputs"
        except Exception:
            pass
    if os.path.isabs(save_path):
        return os.path.normpath(save_path)
    return os.path.normpath(os.path.join(WGP_DIR, save_path))


def _open_folder(path: str) -> None:
    folder_path = os.path.normpath(path)
    os.makedirs(folder_path, exist_ok=True)
    subprocess.Popen(["explorer", folder_path], creationflags=_NO_WIN)


def _center_window_coords(width: int, height: int) -> tuple[int, int]:
    user32 = ctypes.windll.user32
    screen_width = user32.GetSystemMetrics(0)
    screen_height = user32.GetSystemMetrics(1)
    x_pos = max(0, (screen_width - width) // 2)
    y_pos = max(0, (screen_height - height) // 2)
    return x_pos, y_pos


def _center_window_on_screen(window) -> None:
    try:
        native = getattr(window, "native", None)
        handle = getattr(native, "Handle", None) if native is not None else None
        if handle is None:
            return
        hwnd = int(handle)
        user32 = ctypes.windll.user32
        import ctypes.wintypes as wintypes

        rect = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rect))
        width = rect.right - rect.left
        height = rect.bottom - rect.top
        x_pos, y_pos = _center_window_coords(width, height)
        user32.SetWindowPos(hwnd, 0, x_pos, y_pos, 0, 0, 0x0001 | 0x0040)
    except Exception:
        pass


def make_proxy_app(wangp_port_holder: list[int]) -> web.Application:
    shell_html = _load_shell_html()

    async def handle_shell(_request: web.Request) -> web.Response:
        return web.Response(text=shell_html, content_type="text/html", charset="utf-8")

    async def handle_any(request: web.Request) -> web.StreamResponse:
        wangp_port = wangp_port_holder[0]
        upstream = f"127.0.0.1:{wangp_port}"
        path_qs = request.path_qs

        if request.headers.get("Upgrade", "").lower() == "websocket":
            ws_server = web.WebSocketResponse()
            await ws_server.prepare(request)
            async with ClientSession() as session:
                async with session.ws_connect(f"ws://{upstream}{path_qs}") as ws_client:
                    async def forward(source, destination):
                        async for message in source:
                            if message.type == WSMsgType.TEXT:
                                await destination.send_str(message.data)
                            elif message.type == WSMsgType.BINARY:
                                await destination.send_bytes(message.data)

                    await asyncio.gather(forward(ws_server, ws_client), forward(ws_client, ws_server))
            return ws_server

        async with ClientSession(timeout=ClientTimeout(total=120)) as session:
            forward_headers = {
                key: value
                for key, value in request.headers.items()
                if key.lower() not in ("content-encoding", "transfer-encoding")
            }
            forward_headers.update({"Host": upstream, "Origin": f"http://{upstream}"})
            async with session.request(
                request.method,
                f"http://{upstream}{path_qs}",
                headers=forward_headers,
                data=await request.read(),
                allow_redirects=False,
            ) as response:
                body = await response.read()
                response_headers = {
                    key: value
                    for key, value in response.headers.items()
                    if key.lower() not in ("content-encoding", "transfer-encoding", "content-length")
                }
                return web.Response(body=body, status=response.status, headers=response_headers)

    application = web.Application()
    application.router.add_get("/__shell__", handle_shell)
    application.router.add_route("*", "/{path_info:.*}", handle_any)
    return application


class WanGpApi:
    def __init__(self, proxy_port: int, wangp_port_holder: list[int]) -> None:
        self._proxy_port = proxy_port
        self._wangp_port_holder = wangp_port_holder
        self._window = None
        self._process: subprocess.Popen | None = None
        self._settings = _load_settings()
        self._console_detached = bool(self._settings.get("console_detached"))
        self._run_id = 0
        self._url_found = False
        self._ui_lock = threading.Lock()
        self._updating = False
        self._confirm_close = False
        self._skip_next_newline = False

    def set_window(self, window) -> None:
        self._window = window

    def _safe_eval(self, javascript: str) -> None:
        if self._window:
            try:
                self._window.evaluate_js(javascript)
            except Exception:
                pass

    def _println(self, text: str) -> None:
        payload = json.dumps(text)
        self._safe_eval(f"add_to_console({payload})")

    def _print(self, text: str) -> None:
        if self._console_detached:
            try:
                deprecation = "[DEPRECATION WARNING]"
                if deprecation in text and self._settings.get("hide_deprecation_warnings", True):
                    self._skip_next_newline = True
                    return
                if self._skip_next_newline:
                    self._skip_next_newline = False
                    if text == "\n" and self._settings.get("hide_deprecation_warnings", True):
                        return
                sys.stdout.write(text)
                sys.stdout.flush()
            except Exception:
                pass
        else:
            self._println(text)

    def open_in_browser(self) -> None:
        os.startfile(f"http://127.0.0.1:{WANGP_PORT}")

    def open_wangp_folder(self) -> None:
        try:
            _open_folder(WGP_DIR)
        except Exception as error:
            self._println(f"[Folder] Could not open WanGP folder: {error}\n")

    def open_output_folder(self) -> None:
        try:
            _open_folder(_resolve_output_dir())
        except Exception as error:
            self._println(f"[Folder] Could not open output folder: {error}\n")

    def get_ui_settings(self) -> dict:
        return {
            "hideDeprecationWarnings": self._settings.get("hide_deprecation_warnings", True),
            "consoleDetached": self._settings.get("console_detached", False),
        }

    def save_ui_settings(self, settings_json: str) -> None:
        try:
            data = json.loads(settings_json)
            if "hideDeprecationWarnings" in data:
                self._settings["hide_deprecation_warnings"] = bool(data["hideDeprecationWarnings"])
            if "consoleDetached" in data:
                self._settings["console_detached"] = bool(data["consoleDetached"])
            _save_settings(self._settings)
        except Exception:
            pass

    def run_wgp_update(self) -> None:
        if not os.path.isfile(UPDATE_WANGP_BAT):
            self._safe_eval(f"show_update_missing({json.dumps(CONFIG_DIR)})")
            return
        threading.Thread(target=self._do_run_bat, args=(UPDATE_WANGP_BAT,), daemon=True).start()

    def run_wei_update(self) -> None:
        if not os.path.isfile(UPDATE_WEI_BAT):
            self._safe_eval(f"show_update_missing({json.dumps(CONFIG_DIR)})")
            return
        threading.Thread(target=self._do_run_bat, args=(UPDATE_WEI_BAT,), daemon=True).start()

    def detach_console(self) -> bool:
        try:
            kernel32 = ctypes.windll.kernel32
            user32 = ctypes.windll.user32
            kernel32.AllocConsole()
            hwnd = kernel32.GetConsoleWindow()
            if hwnd:
                kernel32.SetConsoleTitleW(f"WanGP Console  [EZi v{APP_VERSION}]")
                user32.ShowWindow(hwnd, 9)
            import msvcrt

            stdout_fd = msvcrt.open_osfhandle(kernel32.GetStdHandle(-11), os.O_WRONLY | os.O_TEXT)
            stderr_fd = msvcrt.open_osfhandle(kernel32.GetStdHandle(-12), os.O_WRONLY | os.O_TEXT)
            sys.stdout = open(stdout_fd, "w", encoding="utf-8", errors="replace", closefd=False)
            sys.stderr = open(stderr_fd, "w", encoding="utf-8", errors="replace", closefd=False)
            self._console_detached = True
            self._settings["console_detached"] = True
            _save_settings(self._settings)
            return True
        except Exception:
            return False

    def reattach_console(self) -> None:
        self._console_detached = False
        self._settings["console_detached"] = False
        _save_settings(self._settings)

    def restart_ezi(self) -> None:
        try:
            launcher = PYW_EXE if os.path.isfile(PYW_EXE) else PY_EXE
            subprocess.Popen(
                [launcher, "-I", EZI_SCRIPT],
                cwd=ROOT_DIR,
                creationflags=0x00000008 | 0x08000000,
            )
        except Exception:
            pass
        self._confirm_close = True
        if self._window:
            try:
                self._window.destroy()
            except Exception:
                pass

    def _kill_process(self) -> None:
        if self._process and self._process.poll() is None:
            try:
                self._process.terminate()
                self._process.wait(timeout=15)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
        self._process = None

    def _navigate_to_ui(self) -> None:
        with self._ui_lock:
            if self._url_found:
                return
            self._url_found = True
        self._safe_eval("set_dot_ready()")
        ui_url = f"http://127.0.0.1:{self._proxy_port}/"
        self._safe_eval(f"load_ui({json.dumps(ui_url)})")

    def _watch_http_ready(self, run_id: int) -> None:
        """Poll WanGP HTTP independently of subprocess stdout (often block-buffered)."""
        deadline = time.time() + 900
        while time.time() < deadline and self._run_id == run_id and not self._url_found:
            if _http_ready(WANGP_PORT):
                self._navigate_to_ui()
                return
            process = self._process
            if process is not None and process.poll() is not None:
                return
            time.sleep(0.5)

    def _build_command(self) -> tuple[list[str], str]:
        script_args = _wangp_script_args()
        bootstrap = _make_wangp_bootstrap(script_args)
        command = [PY_EXE, "-I", "-u", "-X", "utf8=1", "-c", bootstrap]
        display = (
            os.path.relpath(PY_EXE, ROOT_DIR)
            + " -I "
            + os.path.relpath(WGP_SCRIPT, ROOT_DIR)
            + " "
            + " ".join(script_args)
        )
        return command, display

    def _restart_wangp(self) -> None:
        self._url_found = False
        self._run_id += 1
        run_id = self._run_id
        threading.Thread(target=self._run_wangp, args=(run_id,), daemon=True).start()

    def on_loaded(self) -> None:
        if not getattr(self, "_started", False):
            self._started = True
            self._restart_wangp()

    def on_closed(self) -> None:
        self._kill_process()
        _save_settings(self._settings)

    def _run_wangp(self, run_id: int) -> None:
        if not os.path.isfile(PY_EXE):
            self._println("python_embedded\\python.exe not found.\n")
            return
        if not os.path.isfile(WGP_SCRIPT):
            self._println("WanGP\\wgp.py not found.\n")
            return

        threading.Thread(target=self._watch_http_ready, args=(run_id,), daemon=True).start()

        if _http_ready(WANGP_PORT):
            self._navigate_to_ui()
            return

        command, display = self._build_command()
        self._println("\033[2m" + display + "\033[0m\n")
        try:
            self._process = subprocess.Popen(
                command,
                cwd=WGP_DIR,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
                creationflags=_SUBPROCESS_FLAGS,
                env=_wangp_run_env(),
            )
        except Exception as error:
            self._println(f"\033[91mFailed to start WanGP: {error}\033[0m\n")
            return

        if self._process.stdout is not None:
            _stream_pipe_output(
                self._process.stdout,
                run_id,
                self._run_id,
                self._print,
            )

        if self._process.poll() is not None and not self._url_found:
            self._println("\033[91mWanGP exited before the UI was ready.\033[0m\n")

    def _do_run_bat(self, bat_path: str) -> None:
        name = os.path.basename(bat_path)
        self._updating = True
        self._safe_eval(f"switchToConsole({json.dumps('Running ' + name + '...')})")
        self._println("\033[93m=== Stopping WanGP ===\033[0m")
        self._kill_process()
        self._println(f"\033[93m=== Running {name} ===\033[0m")
        try:
            process = subprocess.Popen(
                ["cmd", "/c", "chcp", "65001", ">", "nul", "&&", bat_path, "NoPause"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                cwd=os.path.dirname(bat_path),
                bufsize=0,
                creationflags=_SUBPROCESS_FLAGS,
            )
            if process.stdout is not None:
                _stream_pipe_output(
                    process.stdout,
                    0,
                    0,
                    self._print,
                )
            process.wait()
        except Exception as error:
            self._println(f"\033[91mError running {name}: {error}\033[0m")

        self._println(f"\033[92m=== {name} finished ===\033[0m")
        self._updating = False

        if name.lower() == "update easy-install.bat":
            self._println("\033[92mRestarting WanGP-EZi...\033[0m")
            time.sleep(1)
            self.restart_ezi()
        else:
            self._println("\033[92mRestarting WanGP...\033[0m")
            time.sleep(1)
            self._restart_wangp()


def main() -> None:
    if not os.path.isdir(os.path.join(ROOT_DIR, "python_embedded")):
        ctypes.windll.user32.MessageBoxW(
            0,
            "WanGP-EZi must run from a WanGP-Easy-Install folder.",
            "WanGP-EZi",
            0x10,
        )
        sys.exit(1)

    proxy_port = _find_free_port()
    wangp_port_holder = [WANGP_PORT]
    proxy_loop = asyncio.new_event_loop()
    _load_shell_html()

    def start_proxy() -> None:
        asyncio.set_event_loop(proxy_loop)
        web.run_app(
            make_proxy_app(wangp_port_holder),
            host="127.0.0.1",
            port=proxy_port,
            print=None,
        )

    threading.Thread(target=start_proxy, daemon=True).start()
    _wait_for_tcp_port(proxy_port, timeout=2.0)

    api = WanGpApi(proxy_port, wangp_port_holder)
    atexit.register(api._kill_process)

    window_x, window_y = _center_window_coords(WINDOW_WIDTH, WINDOW_HEIGHT)
    window = webview.create_window(
        f"WanGP-EZi Desktop  v{APP_VERSION}",
        url=f"http://127.0.0.1:{proxy_port}/__shell__",
        js_api=api,
        width=WINDOW_WIDTH,
        height=WINDOW_HEIGHT,
        min_size=(800, 600),
        x=window_x,
        y=window_y,
    )
    api.set_window(window)
    window.events.loaded += api.on_loaded
    window.events.closed += api.on_closed
    window.events.shown += lambda: _center_window_on_screen(window)
    webview.start(gui="edgechromium", debug=False)


if __name__ == "__main__":
    main()
