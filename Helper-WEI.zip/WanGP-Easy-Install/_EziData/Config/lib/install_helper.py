#!/usr/bin/env python3
"""WanGP Easy Install - GPU detection, stack install, wgp_config generation."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

IS_WIN = sys.platform == "win32"
SCRIPT_DIR = Path(__file__).resolve().parent
CONFIG_DIR = SCRIPT_DIR.parent
EZI_DATA_DIR = CONFIG_DIR.parent
INSTALL_ROOT = EZI_DATA_DIR.parent
STACK_CONFIG_PATH = SCRIPT_DIR / "stack_config.json"
INSTALL_PROFILE_PATH = CONFIG_DIR / "install_profile.json"
WAN2GP_DIR = INSTALL_ROOT / "WanGP"
WGP_CONFIG_PATH = WAN2GP_DIR / "wgp_config.json"


def load_stack_config() -> dict:
    with open(STACK_CONFIG_PATH, encoding="utf-8") as file_handle:
        return json.load(file_handle)


def get_gpu_info() -> tuple[str, str]:
    try:
        name = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            encoding="utf-8",
            stderr=subprocess.DEVNULL,
        ).strip()
        if name:
            return name, "NVIDIA"
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        pass

    if IS_WIN:
        try:
            output = subprocess.check_output(
                "wmic path win32_VideoController get name",
                shell=True,
                encoding="utf-8",
                stderr=subprocess.DEVNULL,
            )
            name = output.replace("Name", "").strip().split("\n")[0].strip()
            return name or "Unknown", "UNKNOWN"
        except (subprocess.CalledProcessError, OSError):
            pass

    return "Unknown", "UNKNOWN"


def get_profile_key(gpu_name: str, vendor: str) -> str:
    if vendor == "NVIDIA":
        gpu_upper = gpu_name.upper()
        if re.search(r"RTX\s*5\d", gpu_upper):
            return "RTX_50"
        if re.search(r"RTX\s*4\d", gpu_upper):
            return "RTX_40"
        if re.search(r"RTX\s*3\d", gpu_upper):
            return "RTX_30"
        if re.search(r"RTX\s*2\d", gpu_upper) or "QUADRO" in gpu_upper:
            return "RTX_20"
        return "GTX_10"
    return "GTX_10"


def detect_cuda_stack() -> str:
    """Return cu130 or cu128 based on NVIDIA driver major version."""
    env_stack = os.environ.get("WEI_CUDA_STACK", "").strip()
    if env_stack in ("cu130", "cu128"):
        return env_stack

    try:
        driver_version = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            encoding="utf-8",
            stderr=subprocess.DEVNULL,
        ).strip()
        major = int(driver_version.split(".")[0])
        if major >= 580:
            return "cu130"
    except (subprocess.CalledProcessError, ValueError, OSError, IndexError):
        pass
    return "cu128"


def get_system_specs() -> tuple[float, float]:
    ram_gb = 0.0
    vram_gb = 0.0

    if IS_WIN:
        try:
            output = subprocess.check_output(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory",
                ],
                encoding="utf-8",
                stderr=subprocess.DEVNULL,
            ).strip()
            if output:
                ram_gb = int(output) / (1024**3)
        except (subprocess.CalledProcessError, ValueError, OSError):
            pass

    if ram_gb == 0:
        ram_gb = 16.0

    try:
        output = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            encoding="utf-8",
            stderr=subprocess.DEVNULL,
        ).strip()
        if output:
            vram_gb = float(output.split("\n")[0].strip()) / 1024.0
    except (subprocess.CalledProcessError, ValueError, OSError, IndexError):
        pass

    if vram_gb == 0:
        vram_gb = 8.0

    return ram_gb, vram_gb


def create_wgp_config(profile_key: str) -> None:
    if WGP_CONFIG_PATH.exists():
        return

    WAN2GP_DIR.mkdir(parents=True, exist_ok=True)

    print("\n[*] Auto-generating wgp_config.json based on hardware...")
    ram_gb, vram_gb = get_system_specs()
    print(f"    Detected: {int(ram_gb)}GB RAM / {int(vram_gb)}GB VRAM")

    has_high_ram = ram_gb > 60
    has_mid_ram = ram_gb > 30
    has_huge_vram = vram_gb > 22
    has_high_vram = vram_gb > 11

    if has_high_ram and has_huge_vram:
        profile_id = 1
    elif has_high_ram:
        profile_id = 2
    elif has_mid_ram and has_huge_vram:
        profile_id = 3
    elif has_mid_ram and has_high_vram:
        profile_id = 4
    else:
        profile_id = 5

    if profile_key in ("RTX_50", "RTX_40", "RTX_30"):
        attention_mode = "sage2"
    elif profile_key == "RTX_20":
        attention_mode = "sage"
    else:
        attention_mode = "sdpa"

    compile_mode = "transformer" if profile_key.startswith("RTX_") else ""

    config_output = {
        "attention_mode": attention_mode,
        "compile": compile_mode,
        "video_profile": profile_id,
        "image_profile": profile_id,
        "audio_profile": profile_id,
    }

    with open(WGP_CONFIG_PATH, "w", encoding="utf-8") as file_handle:
        json.dump(config_output, file_handle, indent=4)

    print(
        f"    Created config: profile={profile_id}, "
        f"attention={attention_mode!r}, compile={compile_mode!r}"
    )


def write_install_profile(
    gpu_name: str,
    profile_key: str,
    cuda_stack: str,
    auto_kernels: list[str],
) -> None:
    config = load_stack_config()
    profile = {
        "gpu_name": gpu_name,
        "profile_key": profile_key,
        "cuda_stack": cuda_stack,
        "python": config.get("python", "3.11.9"),
        "auto_kernels": auto_kernels,
    }
    with open(INSTALL_PROFILE_PATH, "w", encoding="utf-8") as file_handle:
        json.dump(profile, file_handle, indent=4)


def read_install_profile() -> dict:
    if not INSTALL_PROFILE_PATH.exists():
        return {}
    with open(INSTALL_PROFILE_PATH, encoding="utf-8") as file_handle:
        return json.load(file_handle)


def get_python_exe() -> Path:
    return INSTALL_ROOT / "python_embedded" / "python.exe"


def run_pip_install(python_exe: Path, package_spec: str, use_uv: bool = True) -> None:
    if not package_spec:
        return

    print(f"\n>>> Installing: {package_spec[:120]}...")
    pip_args = ["--no-cache-dir", "--no-warn-script-location", "--timeout=1000", "--retries=10"]

    if package_spec.startswith("http") or package_spec.endswith(".whl"):
        cmd = [str(python_exe), "-I", "-m", "pip", "install", package_spec] + pip_args
    elif "<" in package_spec and not package_spec.startswith("-"):
        cmd = [str(python_exe), "-I", "-m", "pip", "install", "-U", package_spec] + pip_args
    elif package_spec.startswith("-U "):
        cmd = [str(python_exe), "-I", "-m", "pip", "install"] + package_spec.split() + pip_args
    elif "--index-url" in package_spec:
        parts = package_spec.split()
        cmd = [str(python_exe), "-I", "-m", "pip", "install"] + parts + pip_args
    else:
        if use_uv:
            cmd = [str(python_exe), "-I", "-m", "uv", "pip", "install", package_spec, "--no-cache"]
        else:
            cmd = [str(python_exe), "-I", "-m", "pip", "install", package_spec] + pip_args

    subprocess.run(cmd, check=True, cwd=INSTALL_ROOT)


def uninstall_kernel_packages(python_exe: Path, kernel_name: str, config: dict) -> None:
    packages = config.get("kernel_packages", {}).get(kernel_name, [])
    for package_name in packages:
        subprocess.run(
            [str(python_exe), "-I", "-m", "pip", "uninstall", package_name, "-y"],
            capture_output=True,
            cwd=INSTALL_ROOT,
        )


def install_kernel(python_exe: Path, kernel_name: str, cuda_stack: str | None = None) -> None:
    config = load_stack_config()
    profile = read_install_profile()
    stack_key = cuda_stack or profile.get("cuda_stack") or detect_cuda_stack()
    stack = config["stacks"].get(stack_key)
    if not stack:
        raise ValueError(f"Unknown CUDA stack: {stack_key}")

    package_spec = stack.get(kernel_name)
    if not package_spec:
        print(f"[!] No package defined for kernel '{kernel_name}' on stack {stack_key}")
        return

    uninstall_kernel_packages(python_exe, kernel_name, config)

    if kernel_name == "triton":
        for package_name in ("triton-windows", "triton"):
            subprocess.run(
                [str(python_exe), "-I", "-m", "pip", "uninstall", package_name, "-y"],
                capture_output=True,
                cwd=INSTALL_ROOT,
            )

    if kernel_name in ("sage2", "sage3", "triton", "flash", "sparge", "gguf", "nunchaku", "lightx2v"):
        run_pip_install(python_exe, package_spec, use_uv=False)
        return

    if kernel_name == "bitsandbytes":
        run_pip_install(python_exe, package_spec, use_uv=True)
        return

    run_pip_install(python_exe, package_spec, use_uv=False)


def install_torch(python_exe: Path, cuda_stack: str | None = None) -> str:
    config = load_stack_config()
    stack_key = cuda_stack or detect_cuda_stack()
    stack = config["stacks"][stack_key]
    run_pip_install(python_exe, stack["torch"], use_uv=False)
    return stack_key


def auto_install_kernels(python_exe: Path, profile_key: str, cuda_stack: str) -> list[str]:
    config = load_stack_config()
    kernel_names = config.get("auto_kernels_by_gpu", {}).get(profile_key, [])
    if cuda_stack == "cu128":
        print(
            "[!] Legacy cu128 stack (Torch 2.9.0): nunchaku/gguf wheels are cp310-only and may "
            "fail on Python 3.11. Update NVIDIA drivers (580+) for the recommended cu130 stack."
        )
    for kernel_name in kernel_names:
        try:
            install_kernel(python_exe, kernel_name, cuda_stack)
        except subprocess.CalledProcessError as error:
            print(f"[!] Warning: failed to install {kernel_name}: {error}")
    return kernel_names


def cmd_detect() -> int:
    gpu_name, vendor = get_gpu_info()
    profile_key = get_profile_key(gpu_name, vendor)
    cuda_stack = detect_cuda_stack()
    print(f"GPU: {gpu_name}")
    print(f"Vendor: {vendor}")
    print(f"Profile: {profile_key}")
    print(f"CUDA stack: {cuda_stack}")
    return 0


def cmd_write_profile() -> int:
    gpu_name, vendor = get_gpu_info()
    profile_key = get_profile_key(gpu_name, vendor)
    cuda_stack = detect_cuda_stack()
    config = load_stack_config()
    auto_kernels = config.get("auto_kernels_by_gpu", {}).get(profile_key, [])
    write_install_profile(gpu_name, profile_key, cuda_stack, auto_kernels)
    create_wgp_config(profile_key)
    return 0


def cmd_auto_kernels() -> int:
    python_exe = get_python_exe()
    if not python_exe.exists():
        print("[!] python_embedded not found. Run the main installer first.")
        return 1

    profile = read_install_profile()
    if not profile:
        gpu_name, vendor = get_gpu_info()
        profile_key = get_profile_key(gpu_name, vendor)
        cuda_stack = detect_cuda_stack()
        auto_kernels = auto_install_kernels(python_exe, profile_key, cuda_stack)
        write_install_profile(gpu_name, profile_key, cuda_stack, auto_kernels)
        create_wgp_config(profile_key)
        return 0

    profile_key = profile.get("profile_key", "RTX_40")
    cuda_stack = profile.get("cuda_stack", detect_cuda_stack())
    auto_install_kernels(python_exe, profile_key, cuda_stack)
    return 0


def cmd_install_kernel(kernel_name: str) -> int:
    python_exe = get_python_exe()
    if not python_exe.exists():
        print("[!] python_embedded not found.")
        return 1
    install_kernel(python_exe, kernel_name)
    return 0


def cmd_install_torch(cuda_stack: str | None) -> int:
    python_exe = get_python_exe()
    if not python_exe.exists():
        print("[!] python_embedded not found.")
        return 1

    for package in ("torch", "torchvision", "torchaudio"):
        subprocess.run(
            [str(python_exe), "-I", "-m", "pip", "uninstall", package, "-y"],
            capture_output=True,
        )

    stack_key = install_torch(python_exe, cuda_stack)
    profile = read_install_profile()
    if profile:
        profile["cuda_stack"] = stack_key
        with open(INSTALL_PROFILE_PATH, "w", encoding="utf-8") as file_handle:
            json.dump(profile, file_handle, indent=4)
    print(f"[+] Torch installed with stack: {stack_key}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="WanGP Easy Install helper")
    parser.add_argument("--detect", action="store_true", help="Print GPU/stack detection")
    parser.add_argument("--write-profile", action="store_true", help="Write install_profile.json")
    parser.add_argument("--create-wgp-config", action="store_true", help="Create wgp_config.json")
    parser.add_argument("--auto-kernels", action="store_true", help="Install profile kernels")
    parser.add_argument("--install-kernel", metavar="NAME", help="Install one kernel add-on")
    parser.add_argument("--install-torch", action="store_true", help="Install torch for active stack")
    parser.add_argument("--cuda-stack", choices=["cu130", "cu128"], help="Override CUDA stack")
    args = parser.parse_args()

    if args.detect:
        return cmd_detect()

    if args.write_profile:
        return cmd_write_profile()

    if args.create_wgp_config:
        gpu_name, vendor = get_gpu_info()
        create_wgp_config(get_profile_key(gpu_name, vendor))
        return 0

    if args.auto_kernels:
        return cmd_auto_kernels()

    if args.install_kernel:
        return cmd_install_kernel(args.install_kernel)

    if args.install_torch:
        return cmd_install_torch(args.cuda_stack)

    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
