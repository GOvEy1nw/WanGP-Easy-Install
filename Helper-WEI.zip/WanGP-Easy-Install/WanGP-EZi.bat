@Echo off
if /i not "%~1"=="run" (
    start "WanGP-EZi" /min cmd /c ""%~f0" run"
    exit /b 0
)

cd /D "%~dp0"
Title WanGP-EZi

set "EZI_PY=_EziData\_Extras\Tools\Helper-WEI\WanGP-EZi.py"

if exist "python_embedded\pythonw.exe" (
    start "" "python_embedded\pythonw.exe" -I "%EZI_PY%"
) else (
    start "" "python_embedded\python.exe" -I "%EZI_PY%"
)

REM Let WanGP-EZi open its window, then close this launcher console.
timeout /t 3 /nobreak >nul
exit
