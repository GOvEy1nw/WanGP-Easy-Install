@Echo off&&cd /D %~dp0
Title WanGP Browser
set "path=%windir%\System32;%windir%\System32\WindowsPowerShell\v1.0;%PATH%"
set PORT=7860
for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { 1 } else { 0 }"') do set INUSE=%%A
if "%INUSE%"=="1" (echo WanGP already running on port %PORT%.&pause&exit)
set ARGS=
if exist _EziData\Config\args.txt set /p ARGS=<_EziData\Config\args.txt
pushd WanGP
..\python_embedded\python.exe -I wgp.py --server-port 7860 %ARGS%
popd
pause
